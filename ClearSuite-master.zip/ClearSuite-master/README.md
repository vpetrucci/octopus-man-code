ClearSuite
==========

A set of bash scripts to setup CloudSuite Benchmarks.
